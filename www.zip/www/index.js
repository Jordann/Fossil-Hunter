//////////////////////////////////
// Set the event listener to run when the device is ready
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
// do stuff here
}  